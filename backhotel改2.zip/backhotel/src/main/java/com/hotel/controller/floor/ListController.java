package com.hotel.controller.floor;

import com.alibaba.fastjson.JSONObject;
import com.hotel.pojo.Floor;
import com.hotel.service.FloorService;
import com.hotel.service.impl.FloorServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/floor/list")
public class ListController extends HttpServlet {
    FloorService floorService=new FloorServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       /* String id=request.getParameter("id");
        System.out.println(id);*/
        List<Floor> list= floorService.list();
        // 把list 传给前端
        String str = JSONObject.toJSONString(list);
        response.getWriter().write(str);
    }
}
