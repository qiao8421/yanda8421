package com.hotel.controller.user;

import com.hotel.service.UserService;
import com.hotel.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/user/exist")
public class ExistController extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //1. 设置编码
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        //2. 获取值以后进行判断
        String name = req.getParameter("name") ;

        PrintWriter out = resp.getWriter() ;

        UserService userService = new UserServiceImpl() ;


        if(userService.existUser(name) == -1) {
            out.print("0");
        }else{
            out.print("1");
        }
        out.close();
    }
}
