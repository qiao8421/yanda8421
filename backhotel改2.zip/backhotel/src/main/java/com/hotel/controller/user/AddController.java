package com.hotel.controller.user;

import com.hotel.pojo.User;
import com.hotel.service.UserService;
import com.hotel.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/user/add")
public class AddController extends HttpServlet {
    UserService userService=new UserServiceImpl();
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 把数据接收
        String login= request.getParameter("login");
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String permissions = request.getParameter("permissions");
        String note = request.getParameter("note");
        // 封装到User对象中
       User user = new User(null,login,name,password,Integer.valueOf(permissions),note);
        System.out.println(user);
        // 调用服务层 添加
        int i = userService.add(user);
        // 输出返回值
        response.getWriter().write(String.valueOf(i));
    }
}
