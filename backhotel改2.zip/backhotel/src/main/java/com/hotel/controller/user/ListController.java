package com.hotel.controller.user;

import com.alibaba.fastjson.JSONObject;
import com.hotel.pojo.User;
import com.hotel.service.UserService;
import com.hotel.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/user/list")
public class ListController extends HttpServlet {
    UserService userService=new UserServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<User> list=userService.list();
        String str = JSONObject.toJSONString(list);
        response.getWriter().write(str);
    }
}
