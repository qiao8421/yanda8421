package com.hotel.controller.floor;

import com.hotel.pojo.Floor;
import com.hotel.service.FloorService;
import com.hotel.service.impl.FloorServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/floor/add")
@MultipartConfig
public class AddController extends HttpServlet {
    FloorService floorService= new FloorServiceImpl();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       //把数据接收
        String name = request.getParameter("name");
        String note = request.getParameter("note");
        //封装到Floor对象中
        Floor floor=new Floor(null,name,note);
        System.out.println(floor);
        //调用服务层 添加
        int i = floorService.add(floor);
        //输出返回值
        response.getWriter().write(String.valueOf(i));
    }
}
