package com.hotel.controller.user;

import com.alibaba.fastjson.JSONObject;
import com.hotel.pojo.User;
import com.hotel.service.UserService;
import com.hotel.service.impl.UserServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/user/update")
public class UpdateController extends HttpServlet {
    UserService userService=new UserServiceImpl();
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String id = request.getParameter("id");
        // 调用service 查询单条
        User user = userService.getById(Integer.valueOf(id));
        // 转成json 输出
        response.getWriter().write(JSONObject.toJSONString(user));
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // 接收要修改的数据
        String id = request.getParameter("id");
        String login = request.getParameter("login");
        String name = request.getParameter("name");
        String password = request.getParameter("password");
        String permissions = request.getParameter("permissions");
        String note = request.getParameter("note");
        // 把数据封装到对象中
        User user = new User(Integer.valueOf(id),login,name,password,Integer.valueOf(permissions),note);
        // 调用服务层修改
        int i = userService.update(user);
        // 输出返回值
        response.getWriter().write(String.valueOf(i));
    }
}
