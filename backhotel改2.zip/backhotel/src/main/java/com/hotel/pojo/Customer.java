package com.hotel.pojo;

import lombok.Data;

import java.time.LocalDate;
@Data
public class Customer {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String name;
    private Integer sex;
    private String password;
    private String tele;
    private String email;
    private String address;
    private Integer integral;
    private Integer level;
    private LocalDate lastCtime;
    private LocalDate lastRtime;
    private String note;
}
