package com.hotel.pojo;

import lombok.Data;

import java.math.BigDecimal;

@Data
public class Checkout {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String no;
    private BigDecimal discountPrice;
    private BigDecimal deposit;
    private Integer days;
    private BigDecimal hotelCost;
    private BigDecimal shopCost;
    private BigDecimal mealCost;
    private BigDecimal phoneCost;
    private BigDecimal realCost;
    private BigDecimal reDeposit;
    private Integer paymentType;
    private BigDecimal receivedMoney;
    private BigDecimal changex;
    private Integer userId;
    private String note;
}
