package com.hotel.pojo;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Log {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private Integer	userId;
    private String operation;
    private String password;
    private LocalDateTime time;
    private String note;
}
