package com.hotel.pojo;

import lombok.Data;

@Data
public class GoodsType {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String name;
    private String note;
}
