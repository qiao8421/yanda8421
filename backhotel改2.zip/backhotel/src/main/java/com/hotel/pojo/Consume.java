package com.hotel.pojo;

import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
public class Consume {
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String no;
    private BigDecimal roomNumber;
    private String goodsName;
    private Integer number;
    private BigDecimal goodsPrice;
    private BigDecimal consumeMoney;
    private BigDecimal discountRate;
    private BigDecimal discountMoney;
    private BigDecimal sumMoney;
    private Integer userId;
    private LocalDateTime date;
    private String note;
}
