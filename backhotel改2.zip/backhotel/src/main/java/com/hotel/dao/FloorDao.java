package com.hotel.dao;

import com.hotel.pojo.Floor;

import java.util.List;

public interface FloorDao {
    List<Floor> list();
    int add(Floor floor);
    Floor getById(int id);
    int update(Floor floor);
}
