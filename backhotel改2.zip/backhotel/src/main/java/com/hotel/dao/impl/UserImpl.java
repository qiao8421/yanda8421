package com.hotel.dao.impl;

import com.hotel.dao.UserDao;
import com.hotel.pojo.User;
import com.hotel.until.JdbcUtil;
import java.util.List;

public class UserImpl implements UserDao {
    @Override
    public List<User> list() {
        return JdbcUtil.executeQuery("select id,login,name,password,permissions,note from user",User.class);
    }
    @Override
    public int add(User user) {
        return JdbcUtil.executeUpdate("insert into user(login,name,password,permissions,note) values(?,?,?,?,?)",user.getLogin(),user.getName(),user.getPassword(),user.getPermissions(),user.getNote());
    }

    @Override
    public User getById(int id) {
        return JdbcUtil.getById("select id,login,name,password,permissions,note from user where id=?",User.class,id);
    }

    @Override
    public int update(User user) {
        return JdbcUtil.executeUpdate("update user set login=?,name=?,password=?,permissions=?,note=? where id=?",user.getLogin(),user.getName(),user.getPassword(),user.getPermissions(),user.getNote(),user.getId());
    }
    @Override
    public int existUser(String name) {
        return JdbcUtil.executeUpdate("select count(*) from user where name=?",name);
    }
    @Override
    public User login(String name, String password){
        return JdbcUtil.getById("select * from user where name=? and password=?",User.class,name,password);
    }
}
