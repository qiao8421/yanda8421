package com.hotel.dao.impl;

import com.hotel.dao.GoodsTypeDao;
import com.hotel.pojo.GoodsType;
import com.hotel.until.JdbcUtil;

import java.util.List;

public class GoodsTypeImpl implements GoodsTypeDao {
    @Override
    public List<GoodsType> list() {
        return JdbcUtil.executeQuery("select id,name,note from goods_type",GoodsType.class);
    }
}
