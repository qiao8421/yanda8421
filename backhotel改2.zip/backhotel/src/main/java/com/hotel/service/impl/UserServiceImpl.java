package com.hotel.service.impl;

import com.hotel.dao.UserDao;
import com.hotel.dao.impl.UserImpl;
import com.hotel.pojo.User;
import com.hotel.service.UserService;
import org.apache.commons.codec.digest.DigestUtils;

import java.util.List;

public class UserServiceImpl implements UserService {
    UserDao userDao=new UserImpl();
    @Override
    public List<User> list() {
        return userDao.list();
    }

    @Override
    public int add(User user) {
        user.setPassword( DigestUtils.md5Hex(user.getPassword()));
        return userDao.add(user);
    }

    @Override
    public User getById(int id) {
        return userDao.getById(id);
    }

    @Override
    public int update(User user) {
        user.setPassword( DigestUtils.md5Hex(user.getPassword()));
        return userDao.update(user);
    }

    @Override
    public int existUser(String name) {
        int ret = 0;
        ret = userDao.existUser(name);
        //判断是否大于0
        if(ret > 0) {
            return 1 ;
        }
        return -1;
    }
    @Override
    public User login(String name, String password) {
        password = DigestUtils.md5Hex(password);
        return userDao.login(name,password);
    }
}
