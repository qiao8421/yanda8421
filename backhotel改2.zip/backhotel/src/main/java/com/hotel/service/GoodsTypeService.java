package com.hotel.service;

import com.hotel.pojo.GoodsType;

import java.util.List;

public interface GoodsTypeService {
    List<GoodsType> list();

}
