package com.hotel.service;

import com.hotel.pojo.User;

import java.util.List;

public interface UserService {
    List<User> list();
    int add(User user);
    User getById(int id);
    int update (User user);
    int existUser(String name)  ;
    User login(String name , String password);
}
