package com.hotel.service.impl;

import com.hotel.dao.GoodsTypeDao;
import com.hotel.dao.impl.GoodsTypeImpl;
import com.hotel.pojo.GoodsType;
import com.hotel.service.GoodsTypeService;

import java.util.List;

public class GoodsTypeServiceImpl implements GoodsTypeService {
    GoodsTypeDao goodsTypeDao=new GoodsTypeImpl();

    @Override
    public List<GoodsType> list() {
        return goodsTypeDao.list();
    }
}
