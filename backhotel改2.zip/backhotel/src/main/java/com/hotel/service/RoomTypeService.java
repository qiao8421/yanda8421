package com.hotel.service;

import com.hotel.pojo.RoomType;

import java.util.List;

public interface RoomTypeService {
    List<RoomType> list();
    int add(RoomType roomtype);
    RoomType getById(int id);
    int update(RoomType roomtype);
}
